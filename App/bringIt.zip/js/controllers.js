angular.module('app.controllers', [])
  
.controller('myEventsCtrl', function($scope) {

})
   
.controller('loginCtrl', function($scope) {

})
   
.controller('signupCtrl', function($scope) {

})
   
.controller('createEventCtrl', function($scope) {

})
   
.controller('addPeopleCtrl', function($scope) {

})
   
.controller('thingsToBringCtrl', function($scope) {

})
   
.controller('bringSomethingCtrl', function($scope) {

})
      
.controller('peopleInvitedCtrl', function($scope) {

})
   
.controller('eventDetailsCtrl', function($scope) {

})
    